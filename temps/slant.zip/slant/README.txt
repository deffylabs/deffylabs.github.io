
TITLE: 
Slant - Responsive Free HTML5 template

AUTHOR:
DESIGNED & DEVELOPED by FREEHTML5.co
http://freehtml5.co/
http://twitter.com/fh5co
http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

Unsplash for Photos
http://unsplash.com/

plmd.me for Photos
http://plmd.me/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Modernizr
http://modernizr.com/

Owl Carousel
http://owlgraphic.com/owlcarousel/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/

Google Fonts
https://www.google.com/fonts/

Themify Icons
http://themify.me/themify-icons

Superfish
http://users.tpg.com.au/j_birch/plugins/superfish/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

Easy Responsive Tabs
Samson.Onna <Email : samson3d@gmail.com> 

FastClick
https://github.com/ftlabs/fastclick

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt


